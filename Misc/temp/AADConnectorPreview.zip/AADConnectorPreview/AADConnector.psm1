#-------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation.  All rights reserved.
# Version 0.4 - November 2020
#-------------------------------------------------------------------------

$ErrorActionPreference = "Stop"
$ApiVersion = 2
$paramsRegKey = 'HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\'

if (Test-Path $paramsRegKey)
{
  $installationDirectory = (Get-ItemProperty $paramsRegKey -Name Path).Path
  Import-Module "$installationDirectory\Bin\ADSync\ADSync.psd1"
  Add-Type -Path "$installationDirectory\Bin\Assemblies\Microsoft.MetadirectoryServicesEx.dll"
  Add-Type -Path "$installationDirectory\Bin\Microsoft.MetadirectoryServices.PasswordHashSynchronization.Types.dll"
  Add-Type -Path "$installationDirectory\Extensions\Microsoft.Azure.ActiveDirectory.Connector.dll"
}
else 
{
  Write-Warning -Message "AADConnect installation was not found. Using current directory, some functionality may be unavailable."
  Add-Type -Path "$PSScriptRoot\Microsoft.MetadirectoryServicesEx.dll"
  Add-Type -Path "$PSScriptRoot\Microsoft.MetadirectoryServices.PasswordHashSynchronization.Types.dll"
  Add-Type -Path "$PSScriptRoot\Microsoft.Azure.ActiveDirectory.Connector.dll"
}

function Get-ADSyncAADConnectorImportApiVersion
{
  $paramRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters"
  $paramRegName = "AadConnectorImportApiVersion"

  $version = (Get-ItemProperty -Path $paramRegKey | Select $paramRegName).$paramRegName
  if (-not $version)
  {
    $version = 1
  }

  Write-Output $version
}

function Get-ADSyncAADConnectorExportApiVersion
{
  $aad = Get-ADSyncConnector -Identifier b891884f-051e-4a83-95af-2544101c9083
  $aadRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\" + $aad.Name
  $aadRegName = "EnableNonExistentObjectReferenceExportFiltering"
  $paramRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters"
  $paramRegName = "AadConnectorExportApiVersion"

  $exportType = $aad.ExtensionConfiguration.ExportType
  $enableNonExistentObjectReferenceExportFiltering = 0
  if (Test-Path -Path $aadRegKey)
  {
    $enableNonExistentObjectReferenceExportFiltering = (Get-ItemProperty -Path $aadRegKey | Select $aadRegName).$aadRegName
    if (-not $enableNonExistentObjectReferenceExportFiltering)
    {
      $enableNonExistentObjectReferenceExportFiltering = 0
    }
  }
  $version = (Get-ItemProperty -Path $paramRegKey | Select $paramRegName).$paramRegName
  if (-not $version)
  {
    $version = 1
  }

  if ($version -eq 1)
  {
    if ($exportType -ne 2 -or $enableNonExistentObjectReferenceExportFiltering -ne 0)
    {
      Write-Error "Version mismatch in Registry and AAD Connector. Run Set-ADSyncAADConnectorExportApiVersion to fix the issue"
      return
    }
  }
  elseif ($version -eq 2)
  {
    if ($exportType -ne 5 -or $enableNonExistentObjectReferenceExportFiltering -ne 1)
    {
      Write-Error "Version mismatch in Registry and AAD Connector. Run Set-ADSyncAADConnectorExportApiVersion to fix the issue"
      return
    }
  }
  else
  {
    Write-Error "unknown version $version"
    return
  }

  Write-Output $version
}

function Set-ADSyncAADConnectorImportApiVersion 
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [int] $version
  )

  $regKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters"
  $regName = "AadConnectorImportApiVersion"

  if (($version -ne 1) -and ($version -ne 2))
  {
    Write-Error "unknown version $version"
  }

  Set-ItemProperty -path $regKey -name $regName -value $version

  Write-Output $version
}

function Set-ADSyncAADConnectorExportApiVersion
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [int] $version
  )

  $paramRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters"
  $regName = "AadConnectorExportApiVersion"
  $exportType = $null;
  $enableNonExistentObjectReferenceExportFiltering = 0;

  if ($version -eq 1)
  {
    $exportType = 2 
    $enableNonExistentObjectReferenceExportFiltering = 0
  }
  elseif ($version -eq 2)
  {   
    $exportType = 5
    $enableNonExistentObjectReferenceExportFiltering = 1
  }
  else
  {
    Write-Error "unknown version $version"
  }

  Set-ItemProperty -path $paramRegKey -name $regName -value $version
  $aad = Get-ADSyncConnector -Identifier b891884f-051e-4a83-95af-2544101c9083

  $perMaInstanceRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\"
  if (-not (Test-Path -Path $perMaInstanceRegKey))
  {
    New-Item -Path $perMaInstanceRegKey |  Out-Null
  }
  $aadRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\" + $aad.Name
  if (-not (Test-Path -Path $aadRegKey))
  {
    New-Item -Path $aadRegKey |  Out-Null
  }
  Set-ItemProperty -Path $aadRegKey -Name "EnableNonExistentObjectReferenceExportFiltering" -Value $enableNonExistentObjectReferenceExportFiltering

  $aad.ExtensionConfiguration.ExportType = $exportType
  $aad = Add-ADSyncConnector -Connector $aad

  Write-Output $version
}

function ConvertTo-ADSyncSourceAnchor
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [string] $dn
  )

  $result = [Microsoft.Online.DirSync.Extension.Utilities.DNEncoding]::SafeRdnToString($dn);
  Write-Output $result
}

function ConvertTo-ADSyncAADDistinguishedName
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [string] $sourceAnchor
  )

  $result = [Microsoft.Online.DirSync.Extension.Utilities.DNEncoding]::StringToSafeRdn($sourceAnchor);
  Write-Output $result
}

function ConvertTo-ADSyncCloudAnchor
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [string] $encodedB64Anchor
  )
  $encodedRawAnchor =  [System.Convert]::FromBase64String($encodedB64Anchor);
  $rawAnchor = $encodedRawAnchor[4..($encodedRawAnchor.Length - 3)]
  $cloudAnchor = [System.Text.Encoding]::Unicode.GetString($rawAnchor)
  Write-Output $cloudAnchor
}

function Set-ADSyncMaxImportRefetchSize
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [int] $size
  )

  $paramRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters"
  $regName = "MaxImportRefetchSize"

  Set-ItemProperty -path $paramRegKey -name $regName -value $size

  Write-Output $size
}

function Enable-ADSyncAADConnectorReferenceObsoletion
{
  $aadConnector = Get-ADSyncConnector -Identifier b891884f-051e-4a83-95af-2544101c9083

  $perMaInstanceRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\"
  if (-not (Test-Path -Path $perMaInstanceRegKey))
  {
    New-Item -Path $perMaInstanceRegKey |  Out-Null
  }
  $aadConnectorRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\" + $aadConnector.Name
  if (-not (Test-Path -Path $aadConnectorRegKey))
  {
    New-Item -Path $aadConnectorRegKey |  Out-Null
  }
  Set-ItemProperty -Path $aadConnectorRegKey -Name "EnableReferenceObsoletion" -Value 1

  Write-Output $true
}

function Disable-ADSyncAADConnectorReferenceObsoletion
{
  $aadConnector = Get-ADSyncConnector -Identifier b891884f-051e-4a83-95af-2544101c9083

  $perMaInstanceRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\"
  if (-not (Test-Path -Path $perMaInstanceRegKey))
  {
    New-Item -Path $perMaInstanceRegKey |  Out-Null
  }
  $aadConnectorRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\PerMAInstance\" + $aadConnector.Name
  if (-not (Test-Path -Path $aadConnectorRegKey))
  {
    New-Item -Path $aadConnectorRegKey |  Out-Null
  }
  Set-ItemProperty -Path $aadConnectorRegKey -Name "EnableReferenceObsoletion" -Value 0

  Write-Output $true
}

#
# Sample usage:
#   Full import: Get-ADSyncAadDirectoryChanges -creds $creds -version 2
#
function Get-ADSyncAADDirectoryChanges
{
  Param
  (
    [Parameter(Mandatory=$true)]
    [PSCredential] $creds,

    [Parameter(Mandatory=$false)]
    [byte[]] $watermark,

    [Parameter(Mandatory=$false)]
    [int] $version = 1,

    [Parameter(Mandatory=$false)]
    [string[]] $objectClassFilter
  )

  $enumerator = `
    [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DiagnosticsFactory]::CreateChangeEnumerator( `
        $creds.UserName, `
        $creds.Password, 
        $objectClassFilter, `
        $watermark, `
        ($watermark -eq $null), `
        $version)

  try {
      while ($true) {
        $res = $enumerator.EnumerateNextBatch()
        Write-Output $res
        if (-not $res.AadBatch.MoreToRead) {
            break;
        }
    }
  }
  finally {
    $enumerator.Dispose()
  }
}


<#
.Synopsis
   Gets orphaned objects from Azure AD
.DESCRIPTION
   Reads all objects from Azure AD tenant
.EXAMPLE
   Get-ADSyncAADOrphanedObject -Creds $(Get-Credential) -SyncObjectType 'publicFolder'
.OUTPUTS
   Returns an arrays of objects with SyncObjectType, CloudAnchor, SourceAnchor, DisplayName, Mail
#>
Function Get-ADSyncAADObject
{
    [CmdletBinding()]
    Param
    (
        # Azure AD Global Admin Credentials
        [Parameter(Mandatory=$true, 
                   Position=0)]
        [PSCredential] 
        $Creds,

        # Object Type
        [Parameter(Mandatory=$true,
                   Position=1)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("User", "Group", "Contact", "PublicFolder")]
        $SyncObjectType

    )

    # BEGIN
    Try
    {
        $enumerator = [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DiagnosticsFactory]::CreateChangeEnumerator(`
            $Creds.UserName, `
            $Creds.Password, `
            $SyncObjectType, `
            $null, `
            'Full', `
            $ApiVersion)
    }
    Catch
    {
        Throw "There was a problem initiating Enumerator component. Error Details: $($_.Exception.Message)"
    }

    # PROCESS
    $results = @()
    Do
    {
        $batch = $enumerator.EnumerateNextBatch()
        If ($batch.AadBatch.ResultObjects.Count -gt 0)
        {
            ForEach($entry in $batch.AadBatch.ResultObjects)
            {
                # Skip deleted objects
                If ($entry.SyncOperation -ne 'Delete')
                {
                    $r = $entry | select SyncObjectType
                    # Add all non-null properties as a string value
                    $properties = $entry.PropertyValues
                    #$propertyKeys = $properties.Keys
                    $propertyKeys = @('CloudAnchor','SourceAnchor','DisplayName','Mail')
                    ForEach ($propKey in $propertyKeys)
                    {
                        $propValue = $properties[$propKey]
                        if ($propValue -ne $null)
                        {
                            $propValue = $propValue.ToString()
                        }
                        Else
                        {
                            $propValue = ""
                        }
                        Add-Member -InputObject $r -MemberType NoteProperty -Name $propKey -Value $propValue -Force
                    }
                    $results += $r
                }
            }
        }
    }
    Until ($batch.AadBatch.MoreToRead -eq $false)

    #END
    $enumerator.Dispose()
    $results
}



<#
.Synopsis
   Removes orphaned objects from Azure AD
.DESCRIPTION
   Takes a CSV file SourceAnchor and ObjecType and deletes the respective objects from Azure AD tenant
   in batches of 10 objects using the Global Admin credentials
   It can also take only one user with a given SourceAnchor.
.EXAMPLE
   Remove-ADSyncAADOrphanedObject -InputCsvFilename .\20190801-001055_Disconnectors.csv -Creds (Get-Credential)
.EXAMPLE
   Remove-ADSyncAADOrphanedObject -SourceAnchor '2epFRNMCPUqhysJL3SWL1A==' -SyncObjectType 'publicFolder' -Creds (Get-Credential)
.INPUTS
   InputCsvFilename must point to a CSV file with at least 2 columns: SourceAnchor, SyncObjectType
   When providing a single SourceAnchor as an argument, SyncObjectType is also required
.OUTPUTS
   Shows results from ExportDeletions operation
.NOTES
   DISCLAIMER: Other than User objects that have a Recycle Bin, any other object type DELETED with this function cannot be RECOVERED!
#>
Function Remove-ADSyncAADObject
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                   PositionalBinding=$false,
                   ConfirmImpact='High')]
    Param
    (
        # Azure AD Global Admin Credentials
        [Parameter(Mandatory=$true, 
                   Position=0)]
        [PSCredential] 
        $Creds,


        # CSV Input filename
        [Parameter(ParameterSetName='CsvInput',
                   Mandatory=$true,
                   Position=1)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        $InputCsvFilename,
        
        # Object SourceAnchor
        [Parameter(ParameterSetName='ObjectInput',
                   Mandatory=$true,
                   Position=1)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        $SourceAnchor,

        # Object Type
        [Parameter(ParameterSetName='ObjectInput',
                   Mandatory=$true,
                   Position=2)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("User", "Group", "Contact", "PublicFolder")]
        $SyncObjectType

    )

    # BEGIN
    Write-Verbose "ParameterSetName: $($PSCmdlet.ParameterSetName)"

    Try
    {
        $exporter = `
        [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DiagnosticsFactory]::CreateDirectoryChangeExporter( `
            $Creds.UserName, `
            $Creds.Password)
    }
    Catch
    {
        Throw "There was a problem initiating Exporter component. Error Details: $($_.Exception.Message)"
    }

    If ($($PSCmdlet.ParameterSetName) -eq 'CsvInput')
    {
        Try
        {
            $objects = @(Import-Csv $InputCsvFilename)
            Write-Verbose "CsvInput: $InputCsvFilename | ObjectCount = $($objects.Count)"
        }
        Catch
        {
            Throw "There was a problem importing and processing CSV input file. Error Details: $($_.Exception.Message)"
        }
    }
    Else
    {
        $object = "" | Select SyncObjectType,SourceAnchor
        $object.SyncObjectType = $SyncObjectType
        $object.SourceAnchor = $SourceAnchor
        Write-Verbose "ObjectInput: $($object.SyncObjectType) | $($object.SourceAnchor)"
        $objects = @($object)
    }

    Try
    {
        $entries = @()
        ForEach ($obj in $objects)
        {
            # Lower 1st char
            [string] $syncObjectTypeLowerCase = $($obj.SyncObjectType[0].ToString().ToLower()) + $obj.SyncObjectType.Substring(1)
            Write-Verbose "Processing: DeleteEntry = $syncObjectTypeLowerCase | $($obj.SourceAnchor)"
            # Add DeleteEntry
            $entries += [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DeletionEntry]::FromSourceAnchor($syncObjectTypeLowerCase, $obj.SourceAnchor)
        }
    }
    Catch
    {
        Throw "There was a problem creating DeletionEntry list. Error Details: $($_.Exception.Message)"
    }

    $objsCount = $objects.Count
    $objsProcessed = 0
    $batchSize = 10
    $nextBatch = @()

    # PROCESS
    Try 
    {
        While ($objsProcessed -lt $objsCount) 
        {
            # Progress bar
            $percent = [math]::Round($(($objsProcessed * 100) / $objsCount), 1)
            Write-Progress -Activity "Deleting objects from Azure AD" -Status "$($percent)% Complete:" -PercentComplete $percent;
            
            # Process batch
            $nextBatch = $entries | Select-Object -First $batchSize
            $entries = $entries | Select-Object -Skip $batchSize

            $nextBatch | Out-String

            if ($pscmdlet.ShouldProcess("$($nextBatch.Count) objects", "Delete from Azure AD"))
            {
                $results = $exporter.ExportDeletions([Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DeletionEntry[]]$nextBatch)
                Write-Output $results | FT ResultCode, ResultErrorDescription, ObjectType, SourceAnchor
            }
            else
            {
                Write-Output "SKIPPED: Operation canceled. `n`n"
            }
            $objsProcessed += $nextBatch.Count
        }
    }
    Catch
    {
        Throw "There was a problem processing the batch. Error Details: $($_.Exception.Message)"
    }
    #END 
    $exporter.Dispose()
}
